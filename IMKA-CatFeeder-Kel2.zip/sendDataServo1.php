<?php
	$var2 = $_GET['temp1'];
	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "catfeeder";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	$sql = "INSERT INTO `servo1`(`time_post`, `lapor`) VALUES (NOW(), '".$var2."')";
	if ($conn->query($sql) === TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}
	
	$conn->close();
?>