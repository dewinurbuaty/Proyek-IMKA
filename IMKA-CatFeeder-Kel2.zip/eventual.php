
<?php	
	// Konek ke Database lokal
	$con = mysqli_connect("localhost","root","","catfeeder"); //Change it if required
    
	//Check Connection
        if(mysqli_connect_errno())
        {
            echo "Failed to connect to database" .     mysqli_connect_errno();
        }
		
		$username=$_POST["username"];
		$tanggal=$_POST["tanggal"];
		$jam= $_POST["jam"];
		$porsi=$_POST["porsi"];
		$mix=$_POST["mix0"];
	
	
		$sql = "INSERT INTO jadwaleventual (username,tanggal,jam,porsi,mix) 
                    VALUES     ('$username','$tanggal','$jam','$porsi','$mix')";
					
		//KALO GAGAL EKSEKUSI QUERI
        if (!mysqli_query($con,$sql))
        {
            die('Error: ' . mysqli_error($con));
        }
		
		//KALO BERHASIL NYIMPEN DATA KE DB
        echo "1 record added successfully in the database";
        echo '<br />';
		
		//AKHIRI KONEKSI
        mysqli_close($con);   
?>
