
<?php
include "fungsi.php";
if(isset($_POST["submit2"])){
	$myusername=$_POST['username']; 
	$mypassword=$_POST['pass_pengguna'];
	$hasil=cek_signin($myusername,$mypassword);
}

if(isset($_POST["submit"])){
	$username=$_POST["username"];
	$nama= $_POST["nama"];
	$email= $_POST["email_pengguna"];
	$password=$_POST["pass_pengguna"];
	$hasildaftar=signup($nama,$username,$email,$password);
}							
?>

<html>
		<head>
			<title>Cat Feeder System </title>
			<link href="css/association.css" rel="stylesheet">
			<link href="css/bootstrap.css" rel="stylesheet">
			<link href="css/half-slider.css" rel="stylesheet">	
			<link href="css/bootstrap.min.css" rel="stylesheet">
					

		</head>

		<body>
		<!-- Navigation -->
			<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<div class="title">
<?php
								if(isset($_POST["submit2"])){
									if($hasil==true){
?> 
										<a class="navbar-brand" href="#">Selamat Datang Di Sistem Cat Feeder, <?php echo $myusername;
										
									
									?> !</a>
									
									<?php										
									} else{ ?>
										<a class="navbar-brand" href="#">Email/Password Anda Salah</a>
										
									<?php }
										

								} else {
								?> <a class="navbar-brand" href="#">Selamat Datang Di Sistem Cat Feeder !</a><?php	
								}
							?>
								
							
						</div>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					  </div>
					<!-- /.navbar-collapse -->
				</div>
			</nav>  
			<!-- /.container -->
		   
			<center>
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<img id="026039" src="assets/anigif.gif"></img>									
						</div>
					</div>
				</div>

			</center>
			
			<div class="satu-img">	
			</div>

<?php
	
	if(!isset($_POST["submit"]) && !isset($_POST["submit2"])){
	//ini kondisi awal sebelum sign in/ sign up
	show_form_signup();
	show_form_signin();
?>								
						
			
<?php		
	} else if (isset($_POST["submit"])){
		//ini kondisi saat signup berhasil
?>
		<a class="navbar-brand" href="#">Pendaftaran Berhasil !</a>
<?php
		show_form_signin();
		
		

	} else if(isset($_POST["submit2"]) ){
	//ini kondisi saat sign in
		if ($hasil==true)
			//show_menubar();
?>
			<div class="container">
									<div class="satu">
									<div class= "menu">														
									<ul class="nav nav-pills">
										<li> 
											<form action="CF_Awal.php" method="post" enctype="multipart/form-data">			
												<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
												<input type="hidden" name="pass_pengguna" id="pass_pengguna" value="<?php echo $mypassword ?>">
												<input type="submit" value="Profil Kucing" name="profil">
											</form>
										</li>
										
										<li> 
											<form action="CF_Form.php" method="post" enctype="multipart/form-data">			
												<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
												<input type="hidden" name="pass_pengguna" id="pass_pengguna" value="<?php echo $mypassword ?>">
												<input type="submit" value="Input Jadwal" name="inputjadwal">
											</form>
										</li>
										
										<li> 
											<form action="CF_Jadwal.php" method="post" enctype="multipart/form-data">			
												<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
												<input type="hidden" name="pass_pengguna" id="pass_pengguna" value="<?php echo $mypassword ?>">
												<input type="submit" value="Lihat Jadwal" name="lihatjadwal">
											</form>
										</li>
										
										<li> 
											<form action="CF_Awal.php" method="post" enctype="multipart/form-data">			
												<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
												<input type="hidden" name="pass_pengguna" id="pass_pengguna" value="<?php echo $mypassword ?>">
												<input type="submit" value="     Logout     " name="logout">
											</form>
										</li>
										
										
									</ul>
									</div>
<?php		
		} else{
			show_form_signin();
			show_form_signup();
		}
?>
<!-- Page Content -->
			<div class="container">
			
			</div>
			</div>
			
				<!-- Footer -->
				<footer>
					<div class="row">
						<div class="copyright">
								<p>STI 2013 - Kelompok 2 - IMKA - 2016</p>
							</div>
					</div>
					<!-- /.row -->
				</footer>

		</body>

</html>