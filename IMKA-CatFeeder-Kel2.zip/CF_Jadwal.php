<html>
	<head>
		<title>Cat Feeder System | J A D W A L  M A K A N</title>
		<link href="css/association.css" rel="stylesheet">
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/half-slider.css" rel="stylesheet">	
		<link href="css/bootstrap.min.css" rel="stylesheet">
	</head>

	<body>
	<!-- Navigation -->
		<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<div class="title">				
						<a class="navbar-brand" href="#">Cat Feeder System | J A D W A L  M A K A N</a> 
					</div>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				  </div>
				<!-- /.navbar-collapse -->
			</div>
		</nav>  
		<!-- /.container -->
	   
		<center>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<img id="026039" src="assets/anigif.gif"></img>									
					</div>
				</div>
			</div>

		</center>
		
		<div class="satu-img">	
		</div>
		
<?php
include "fungsi.php";

if(isset($_POST["lihatjadwal"])){	
	$myusername=$_POST['username']; 
	$mypassword=$_POST['pass_pengguna'];
	
	$hasil=cek_signin($myusername,$mypassword);
		if($hasil==true){
?>
			<div class="container">
			<div class="satu">
			<div class= "menu">
									<ul class="nav nav-pills">
										<li> 
											<form action="CF_Awal.php" method="post" enctype="multipart/form-data">			
												<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
												<input type="hidden" name="pass_pengguna" id="pass_pengguna" value="<?php echo $mypassword ?>">
												<input type="submit" value="Profil Kucing" name="profil">
											</form>
										</li>
										
										<li> 
											<form action="CF_Form.php" method="post" enctype="multipart/form-data">			
												<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
												<input type="hidden" name="pass_pengguna" id="pass_pengguna" value="<?php echo $mypassword ?>">
												<input type="submit" value="Input Jadwal" name="inputjadwal">
											</form>
										</li>
										
										<li> 
											<form action="CF_Jadwal.php" method="post" enctype="multipart/form-data">			
												<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
												<input type="hidden" name="pass_pengguna" id="pass_pengguna" value="<?php echo $mypassword ?>">
												<input type="submit" value="Lihat Jadwal" name="lihatjadwal">
											</form>
										</li>
										
										<li> 
											<form action="CF_Awal.php" method="post" enctype="multipart/form-data">			
												<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
												<input type="hidden" name="pass_pengguna" id="pass_pengguna" value="<?php echo $mypassword ?>">
												<input type="submit" value="     Logout     " name="logout">
											</form>
										</li>
										
										
									</ul>
			</div>
			<div class="satu-txt">
				<p>Selamat Datang,  <b><?php echo $myusername;?></b></p>
				<br>
				<legend> <b>Status Stok Makanan</b></legend>
				<b>Stok Makanan:</b> <?php
					$connection = mysql_connect('localhost','root','');
					mysql_select_db('catfeeder');
					$query = "SELECT * FROM ldr ORDER BY id_pembacaan DESC LIMIT 1";
					//$query = "SELECT * FROM sensorldr ORDER BY id_pembacaan DESC LIMIT 1";
					$result = mysql_query($query);
					$row=mysql_fetch_array($result);
					//$nilai=$row['nilai_ldr'];
					$nilai=$row['ldr'];
					//echo $nilai;
					if ($nilai=0){ //ini bisa diganti, <10 aja gitu? hmm
						echo "Masih cukup";
					}
					else{
						echo "Tidak cukup, harus segera diisi ulang";
					}
					
					mysql_close();	
				?>
				<br></br>
				
				<br>
				<legend> <b>Status Pemberian Makan</b></legend>
				<?php
					$connection = mysql_connect('localhost','root','');
					mysql_select_db('catfeeder');
					//servo2 --> servo untuk buka tutup stok makanan
					//servo1 --> servo yang berputar
					$query = "SELECT * FROM servo2 WHERE lapor=1 ORDER BY id DESC LIMIT 1";
					$result = mysql_query($query);
					$row=mysql_fetch_array($result);
					//$tanggal=$row['tanggal'];
					//$jam=$row['jam'];
					$time_post=$row['time_post'];
					$lapor=$row['lapor'];
					mysql_close();
				?>
				<center>
				<table>	
					<tr>Pemberian makan terakhir:</tr>
					<tr><td><th>Tanggal, jam</th></td> <td><?php echo $time_post;?></td></tr>
				
					<tr><td><th>Porsi</th></td> <td><?php echo "1";?></td></tr>
				<br></br>
				
				<table>
				</center>
				
				<br>
				<legend> <b>History Jadwal Makan Kucing (Harian)</b></legend> 	
				<center>
				<table border="1">
									<tr>
										<th> Username </th>
										<th> Jam Makan Pagi </th>
										<th> Porsi Pagi </th>
										<th> Mix? </th>
										<th> Jam Makan Siang </th>
										<th> Porsi Siang </th>
										<th> Mix? </th>
										<th> Jam Makan Malam </th>
										<th> Porsi Malam </th>
										<th> Mix? </th>
									</tr>
				 
				<?php
					$connection = mysql_connect('localhost','root','');
					mysql_select_db('catfeeder');
					$query = "SELECT * FROM jadwalharian WHERE username='" . $myusername . "' ORDER BY id_jadwal DESC";
					//$query = "SELECT username FROM jadwalharian WHERE id_jadwal=1";
					$result = mysql_query($query);
					//echo $result;
					while ($row=mysql_fetch_array($result)){		
						echo "<tr><td>" . $row['username']."</td><td>" .$row['makan_pagi'] ."</td><td>" . $row['porsi_pagi']."</td><td>" . $row['mix']."</td><td>" .$row['makan_siang'] ."</td><td>" . $row['porsi_siang']."</td><td>". $row['mix2']."</td><td>" .$row['makan_malam']."</td><td>".$row['porsi_malam'] ."</td><td>". $row['mix3']."</td></tr>";
					}
					
					mysql_close();	
				?>
					
				</table>
				</center>
				<br></br>
				
		</div>
				<div class="satu-txt">
				
				<legend> <b>History Jadwal Makan Kucing (Eventual)</b></legend>
				<center>
				<table border="1">
									<tr>
										<th> Username </th>
										<th> Tanggal Makan </th>
										<th> Jam Makan </th>
										<th> Porsi </th>
										<th> Mix? </th>
										
									</tr>
				 
				<?php
					$connection = mysql_connect('localhost','root','');
					mysql_select_db('catfeeder');
					$query = "SELECT * FROM jadwaleventual WHERE username='" . $myusername . "'ORDER BY id_jadwal DESC";
					$result = mysql_query($query);
					while ($row=mysql_fetch_array($result)){		
						echo "<tr><td>" . $row['username']."</td><td>" .$row['tanggal'] ."</td><td>" . $row['jam']."</td><td>" .$row['porsi'] ."</td>,<td>" . $row['mix']."</td></tr>";
					}
				?>
					
				</table>
				<br>**Keterangan: 
				<br>Mix=0 --> tidak mix
				<br>Mix=1 --> menu di-mix
				
				<?php
					mysql_close();		
			} 
			else {
			
?>
			
			</center>
			</div>
			<center>			
			<div class="satu">
				<h2>Sign In/ Sign Up Dulu yaaaaaa...</h2>
			</center>
			
<?php
			show_form_signin();
			show_form_signup();
		}

} else {
?>
			<center>			
			<div class="satu">
				<h2>Sign In/ Sign Up Dulu yaaaaaa...</h2>
			</center>
<?php
	show_form_signin();
	show_form_signup();
	}
?>
<!-- Footer -->
			<footer>
				<div class="row">
					<div class="copyright">
							<p>STI 2013 - Kelompok 2 - IMKA - 2016</p>
						</div>
				</div>
				<!-- /.row -->
			</footer>

	</body>
</html>

