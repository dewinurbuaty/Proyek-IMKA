<?php
	// Konek ke Database lokal
	$con = mysqli_connect("localhost","root","","catfeeder"); //Change it if required
    
	//Check Connection
        if(mysqli_connect_errno())
        {
            echo "Failed to connect to database" .     mysqli_connect_errno();
        }
		
		$username=$_POST["username"];
		$makanpagi=$_POST["makanpagi"];
		$porsipagi=$_POST["porsi1"];
		$mix=$_POST["mix"];
		
		$launch= $_POST["launch"];
		$porsisiang=$_POST["porsi2"];
		$mix2=$_POST["mix2"];

		$dinner= $_POST["dinner"];
		$porsimalam=$_POST["porsi3"];
		$mix3=$_POST["mix3"];

	
	//Perintah query
		$sql = "INSERT INTO jadwalharian (username,makan_pagi,porsi_pagi,makan_siang,porsi_siang,makan_malam, porsi_malam,mix,mix2,mix3) 
                    VALUES     ('$username','$makanpagi','$porsipagi','$launch','$porsisiang','$dinner','$porsimalam','$mix','$mix2','$mix3')";
		
	//KALO GAGAL EKSEKUSI QUERI
        if (!mysqli_query($con,$sql))
        {
            die('Error: ' . mysqli_error($con));
        }
		
	//KALO BERHASIL NYIMPEN DATA KE DB
        echo "1 record added successfully in the database";
        echo '<br />';
		
		//AKHIRI KONEKSI
        mysqli_close($con);   
?>