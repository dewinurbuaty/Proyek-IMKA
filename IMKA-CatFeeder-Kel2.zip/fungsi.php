<?php
function cek_signin($myusername, $mypassword){
	$host="localhost"; // Host name 
	$username="root"; // Mysql username 
	$password=""; // Mysql password 
	$db_name="catfeeder"; // Database name 
	$tbl_name="pengguna"; // Table name 

	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
	mysql_select_db("$db_name")or die("cannot select DB");
	// username and password sent from form 
								
	// To protect MySQL injection (more detail about MySQL injection)
	$myusername = stripslashes($myusername);
	$mypassword = stripslashes($mypassword);
	$myusername = mysql_real_escape_string($myusername);
	$mypassword = mysql_real_escape_string($mypassword);
	$sql="SELECT * FROM $tbl_name WHERE username='$myusername' and password='$mypassword'";
	$result=mysql_query($sql);

	// Mysql_num_row is counting table row
	$count=mysql_num_rows($result);

	// If result matched $myusername and $mypassword, table row must be 1 row
	if($count==1){ 
		//session_start();
		$_SESSION['myusername']=$myusername;
		$session_sekarang=session_name($myusername);
		$hasil=true;
		//header("location:CF_Form.php");
	}
	else {
		//header("location:CF_Awal.php");
		//echo "Wrong Username or Password";
		$hasil=false;
	}									
	return $hasil;
}

function show_form_signup(){
?>
	<div class="container">
			<div class="satu">
				<div class="satu-txt">
					<legend><p><b>Sign Up ke Sistem Cat Feeder</b></p></legend>
						<fieldset>
							<form action="" method="post" enctype="multipart/form-data">			
								Nama Lengkap: <input type="text" name="nama" id="nama" required>			
								<br></br>Jenis Kelamin:
									<select name="pilihan" required>
										<option value="Perempuan" >Perempuan</option>
										<option value="Laki-Laki">Laki-laki</option>
										<option value="Lainnya">Lainnya</option>	
									</select>
								<br></br>Username: <input type="text" name="username" id="username" required>
								<br></br>Email: <input type="text" name="email_pengguna" id="email_pengguna" required>
								<br></br>Password: <input type="text" name="pass_pengguna" id="pass_pengguna" required>				
											
								<br></br><input type="submit" value="Sign Me Up" name="submit">
							</form>
						</fieldset>
						</div>
			</div>
	</div>

<?php
	
}

function show_form_signin(){
?>
	<div class="container">
			<div class="satu">
				<div class="satu-txt">
					<legend><p><b>Sign In ke Sistem Cat Feeder</b></p></legend>
										<fieldset>
											<form action="" method="post" enctype="multipart/form-data">			
												Username: <input type="text" name="username" id="username" required>
												<br></br>Password: <input type="text" name="pass_pengguna" id="pass_pengguna" required>
												<br></br><input type="submit" value="Sign Me In" name="submit2">
											</form>							
											
										</fieldset>
				</div>
			</div>
	</div>
<?php	
}

function signup($nama,$username,$email,$password){
	// Konek ke Database lokal
    $con = mysqli_connect("localhost","root","","catfeeder"); //Change it if required

	//Check Connection
        if(mysqli_connect_errno())
        {
            echo "Failed to connect to database" .     mysqli_connect_errno();
			$hasildaftar=false;
        }
        $sql = "INSERT INTO pengguna (nama, username, email, password)
                    VALUES     ('$nama','$username','$email','$password') ";

        if (!mysqli_query($con,$sql))
        {
            die('Error: ' . mysqli_error($con));
        }
        //echo "1 record added successfully in the database";
        //echo '<br />';
		$hasildaftar=true;
        mysqli_close($con); 

	return $hasildaftar;
	
}
/*
function logout(){
// Put this code in first line of web page. 
session_start();
session_destroy();
}

function simpan_username (){
	$myusername=$_POST['username']; 
}

function show_jadwal(){
}
*/							
?>