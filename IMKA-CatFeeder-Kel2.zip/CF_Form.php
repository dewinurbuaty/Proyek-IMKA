<html>
	<head>
		<title>Cat Feeder System | I N P U T   J A D W A L  M A K A N</title>
		<link href="css/association.css" rel="stylesheet">
		<link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/half-slider.css" rel="stylesheet">	
		<link href="css/bootstrap.min.css" rel="stylesheet">
	</head>

	<body>
	<!-- Navigation -->
		<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<div class="title">				
						<a class="navbar-brand" href="#">Cat Feeder System | I N P U T   J A D W A L   M A K A N</a> 
					</div>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				  </div>
				<!-- /.navbar-collapse -->
			</div>
		</nav>  
		<!-- /.container -->
	   
		<center>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<img id="026039" src="assets/anigif.gif"></img>									
					</div>
				</div>
			</div>

		</center>
		
		<div class="satu-img">	
		</div>
		
<?php
include "fungsi.php";
$myusername=$_POST['username']; 
$mypassword=$_POST['pass_pengguna'];

if(isset($_POST["inputjadwal"])){	
	$myusername=$_POST['username']; 
	$mypassword=$_POST['pass_pengguna'];
	$hasil=cek_signin($myusername,$mypassword);
	
		if($hasil==true){
?>
			<div class="container">
			<div class="satu">
			<div class= "menu">
									<ul class="nav nav-pills">
										<li> 
											<form action="CF_Awal.php" method="post" enctype="multipart/form-data">			
												<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
												<input type="hidden" name="pass_pengguna" id="pass_pengguna" value="<?php echo $mypassword ?>">
												<input type="submit" value="Profil Kucing" name="profil">
											</form>
										</li>
										
										<li> 
											<form action="CF_Form.php" method="post" enctype="multipart/form-data">			
												<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
												<input type="hidden" name="pass_pengguna" id="pass_pengguna" value="<?php echo $mypassword ?>">
												<input type="submit" value="Input Jadwal" name="inputjadwal">
											</form>
										</li>
										
										<li> 
											<form action="CF_Jadwal.php" method="post" enctype="multipart/form-data">			
												<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
												<input type="hidden" name="pass_pengguna" id="pass_pengguna" value="<?php echo $mypassword ?>">
												<input type="submit" value="Lihat Jadwal" name="lihatjadwal">
											</form>
										</li>
										
										<li> 
											<form action="CF_Awal.php" method="post" enctype="multipart/form-data">			
												<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
												<input type="hidden" name="pass_pengguna" id="pass_pengguna" value="<?php echo $mypassword ?>">
												<input type="submit" value="     Logout     " name="logout">
											</form>
										</li>
										
										
									</ul>
			</div>
			
										<div class="satu-txt">
										
							<p>Selamat Datang,  <b><?php echo $myusername;?></b></p>
							<br>
							<legend><p><b>FORM JADWAL PEMBERIAN MAKAN KUCING HARIAN</b></p></legend>
								<fieldset>
									<form action="harian.php" method="post" enctype="multipart/form-data">			
										Makan Pagi: <input type="time" name="makanpagi" id="makanpagi">	
										Porsi (cup): 
										<select name="porsi1")>
												<option value="1" >1</option>
												<option value="2">2</option>
												<option value="3">3</option>
												<option value="4">4</option>									
											</select>											
										Mix?: 
										<select name="mix">
												<option value="1" >Ya</option>
												<option value="0">Tidak</option>								
											</select>
										<br></br>Makan Siang: <input type="time" name="launch" id="launch">	
										Porsi (cup): 
										<select name="porsi2">
												<option value="1" >1</option>
												<option value="2">2</option>
												<option value="3">3</option>
												<option value="4">4</option>									
											</select>
										Mix?: 
										<select name="mix2">
												<option value="1" >Ya</option>
												<option value="0">Tidak</option>								
											</select>
										<br></br>Makan Malam: <input type="time" name="dinner" id="dinner">	
										Porsi (cup): 
										<select name="porsi3">
												<option value="1" >1</option>
												<option value="2">2</option>
												<option value="3">3</option>
												<option value="4">4</option>									
											</select>
										Mix?: 
										<select name="mix3">
												<option value="1" >Ya</option>
												<option value="0">Tidak</option>								
											</select>
										<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
										<br></br><input type="submit" value="OK" name="jadwalharian">
									</form>
								</fieldset>
								
						</div>
						<br></br>
						<div class="satu-txt">
							<legend><p><b>FORM JADWAL PEMBERIAN MAKAN KUCING EVENTUAL</b></p></legend>
								<fieldset>
									<form action="eventual.php" method="post" enctype="multipart/form-data">
										Tanggal: <input type="date" name="tanggal" id="tanggal">			
										<br></br>Jam: <input type="time" name="jam" id="jam">
										<br></br>Porsi (cup): 
										<select name="porsi")>
												<option value="1" >1</option>
												<option value="2">2</option>
												<option value="3">3</option>
												<option value="4">4</option>									
											</select>
											Mix?: 
										<select name="mix0">
												<option value="1" >Ya</option>
												<option value="0">Tidak</option>								
											</select>
										<input type="hidden" name="username" id="username" value="<?php echo $myusername ?>">
										<br></br><input type="submit" value="OK" name="jadwaleventual">
									</form>
								</fieldset>
						
								
						</div>

			
<?php		
		} 
		else {
?>
			<center>			
			<div class="satu">
				<h2>Sign In/ Sign Up Dulu yaaaaaa...</h2>
			</center>
			
<?php
			show_form_signin();
			show_form_signup();
		}

} else {
?>
			<center>			
			<div class="satu">
				<h2>Sign In/ Sign Up Dulu yaaaaaa...</h2>
			</center>
<?php
	show_form_signin();
	show_form_signup();
	}
?>
<!-- Footer -->
			<footer>
				<div class="row">
					<div class="copyright">
							<p>STI 2013 - Kelompok 2 - IMKA - 2016</p>
						</div>
				</div>
				<!-- /.row -->
			</footer>

	</body>
</html>

