<?php
	$var3 = $_GET['temp2'];
	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "catfeeder";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	$sql = "INSERT INTO `servo2`(`time_post`, `lapor`) VALUES (NOW(), '".$var3."')";
	if ($conn->query($sql) === TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}
	
	$conn->close();
?>